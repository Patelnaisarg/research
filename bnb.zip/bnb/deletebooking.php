<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Deletation</title>
</head>
<body>
<h2><a href='listbookings.php'>[Return to booking list]</a><a href="/bnb/">[Return to main page]</a></h2>
<textarea id="text" name="text" rows="8" cols="50">
        Room name:milan

        Checkin date:2018-09-19

        checkout date:2018-09-19
        
    
</textarea>
<br>
<button>Delete</button>
</body>
</html>