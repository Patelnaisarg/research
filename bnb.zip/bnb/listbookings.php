<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking listing</title>
</head>
<body>
  <h1>Current Bookings</h1>
<h2><a href='booking.php'>[Add a Booking]</a><a href="/bnb/">[Return to main page]</a></h2>
<table border="1">
<tr>
    <th>Booking(Room,Date)</th>
    <th>customer</th>
    <th>Actoin</th>
  </tr>
  <tr>
    <td>Patel,Date(check in),(checkout)</td>
    <td>Milan,Binal</td>
    <td><a href="booking view.php">[view]</a><a href="editbooking.php">[edit]</a><a href="deletebooking.php">[Delete booking]</a></td>
  </tr>
  <tr>
  <td>Patel,Date(check in),(checkout)</td>
    <td>Vikram,--</td>
    <td>[view][edit][Delete booking]</td>
  </tr>
  <tr>
  <td>Patel,Date(check in),(checkout)</td>
    <td>vishal,Binal</td>
    <td>[view][edit][Delete booking]</td>
  </tr>
  <tr>
  <td>Raval,Date(check in),(checkout)</td>
    <td>Beer,Grills</td>
    <td>[view][edit][Delete booking]</td>
  </tr>
  <tr>
  <td>Raval,Date(check in),(checkout)</td>
    <td>Andrew,Bill</td>
    <td>[view][edit][Delete booking]</td>
  </tr>
  
 
</table>
</body>
</html>