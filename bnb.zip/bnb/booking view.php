<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking view</title>
</head>
<body>
<h2><a href='listbookings.php'>[Return to booking list]</a><a href="/bnb/">[Return to main page]</a></h2>
    <div>
    <textarea id="text" name="text" rows="15" cols="50">
        Room name:Milan

        Checkin date:06/26/2018

        checkout date:06/30/2018
        
        Contact Number:(001)123 1234
        
        Extras:Nothing
        
        Room Review:nothing
</textarea>
    </div>
    
</body>
</html>